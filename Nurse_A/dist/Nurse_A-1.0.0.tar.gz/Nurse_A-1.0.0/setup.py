from distutils.core import setup

setup(
    name = 'Nurse_A',
    version = '1.0.0',
    packages = ['Nurse_A', 'Nurse_A.Platform', 'Nurse_A.Scenario', 'Nurse_A.Settings'],
    author = 'AlexGao',
    author_email = 'ianxiaohanxu@163.com',
    url = 'http://',
    description = 'None',
    )
