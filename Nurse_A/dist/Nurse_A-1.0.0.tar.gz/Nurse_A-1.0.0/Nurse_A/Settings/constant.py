

INTERVAL_1               =       0.1
INTERVAL_5               =       0.5