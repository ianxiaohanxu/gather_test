HK_DOCTOR                   =   'alex+hk@gatherhealth.com'
INDIA_DOCTOR                =   'alex+in@gatherhealth.com'
US_DOCTOR                   =   'alex+us@gatherhealth.com'

Stag0                       =   'http://stag0.gatherhealth.com/provider/'
Stag1                       =   'https://stag1.gatherhealth.com/provider'
Stag2                       =   'https://stag2.gatherhealth.com/provider'
Production                  =   'https://www.gatherhealth.com/provider'

PR_LOGIN_TITLE              =   u'Gather \u22c5 Login'