HK_DOCTOR                   =   'alex+hk@gatherhealth.com'
INDIA_DOCTOR                =   'alex+in@gatherhealth.com'
US_DOCTOR                   =   'alex+us@gatherhealth.com'
PASSWORD                    =   '123456'

Stag0                       =   'http://stag0.gatherhealth.com/provider/'
Stag1                       =   'https://stag1.gatherhealth.com/provider'
Stag2                       =   'https://stag2.gatherhealth.com/provider'
Production                  =   'https://www.gatherhealth.com/provider'
SERVER                      =   Stag2
DIRECTORY_PATH              =   SERVER+'/directory'

PR_LOGIN_TITLE              =   u'Gather \u22c5 Login'
HKID                        =   'X356888'
HKID_CHECK                  =   'A'
ADD_PATIENT                 =   u'ADD PATIENT'

# Locator
PR_ADD_PATIENT_BUTTON                       =   '.normal .add a'
PR_ADD_PATIENT_SURNAME                      =   'input[name="last_name"]'
PR_ADD_PATIENT_GIVENAME                     =   'input[name="first_name"]'
PR_ADD_PATIENT_P_COUNTRY_CODE               =   'select[name="phone1_country"]'
PR_ADD_PATIENT_P_NUMBER                     =   'input[name="phone1"]'
PR_ADD_PATIENT_EMAIL                        =   'input[name="email"]'
PR_ADD_PATIENT_LANGUAGE                     =   'select[name="language"]'
PR_ADD_PATIENT_GENDER_MALE                  =   'input[name="sex"][value="0"]'
PR_ADD_PATIENT_GENDER_FEMALE                =   'input[name="sex"][value="1"]'
PR_ADD_PATIENT_HAS_HKID_NO                  =   'input[name="has_hkid"][value="false"]'
PR_ADD_PATIENT_HAS_HKID_YES                 =   'input[name="has_hkid"][value="true"]'
PR_ADD_PATIENT_HKID                         =   'input[name="hkid"]'
PR_ADD_PATIENT_HKID_CHECK                   =   'input[name="hkid_check"]'
PR_ADD_PATIENT_PREMIUM_TRIAL                =   '#premium_trial_subscription'
PR_ADD_PATIENT_INVITE_BUTTON                =   'input.full_width'
PR_ADD_PATIENT_FINAL_BUTTON                 =   'button.final'
PR_ADD_PATIENT_TITLE                        =   '.heading h1'

PR_PATIENT_RECORD_ID                        =   '.id span'

PR_DIRECTORY_REMOVE_CONFIRM                 =   '.cleared .right.submit'
